package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import es.ucm.fdi.lps.g08.Colores;

public class elegirColores extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private ButtonGroup grupoBotones;
	private JButton btnAceptar;
	private JRadioButton rdbtnRojo,rdbtnAzul,rdbtnVerde,rdbtnBlanco,rdbtnAmarillo,rdbtnNegro;
	private Colores color = Colores.Auxiliar;
	private ArrayList<Colores> listaColores;
	private boolean pulsaAceptar;
	
	public elegirColores() {
		super("Elige un color");
		listaColores = new ArrayList<Colores>();
		pulsaAceptar = false;
	}
	
	public void creaVentana(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//No permite Maximizar la ventana
		setResizable(false);
		setBounds(100, 100, 216, 315);
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.setBounds(56, 215, 89, 23);
		panel.add(btnAceptar);
		if(btnAceptar.isSelected()){
			dispose();
		}
		
		//listaColores = c;
		
		grupoBotones = new ButtonGroup();

		rdbtnRojo = new JRadioButton("Rojo");
		rdbtnRojo.setBounds(55, 29, 109, 23);
		panel.add(rdbtnRojo);
		grupoBotones.add(rdbtnRojo);
					
		rdbtnAzul = new JRadioButton("Azul");
		rdbtnAzul.setBounds(55, 58, 109, 23);
		panel.add(rdbtnAzul);
		grupoBotones.add(rdbtnAzul);
		
		rdbtnBlanco = new JRadioButton("Blanco");
		rdbtnBlanco.setBounds(55, 84, 109, 23);
		panel.add(rdbtnBlanco);
		grupoBotones.add(rdbtnBlanco);
		
		rdbtnVerde = new JRadioButton("Verde");
		rdbtnVerde.setBounds(55, 110, 109, 23);
		panel.add(rdbtnVerde);
		grupoBotones.add(rdbtnVerde);
		
		rdbtnAmarillo = new JRadioButton("Amarillo");
		rdbtnAmarillo.setBounds(55, 133, 109, 23);
		panel.add(rdbtnAmarillo);
		grupoBotones.add(rdbtnAmarillo);
		
		rdbtnNegro = new JRadioButton("Negro");
		rdbtnNegro.setBounds(55, 159, 109, 23);
		panel.add(rdbtnNegro);
		grupoBotones.add(rdbtnNegro);
		
		bloquearBotones();
			
		ActionListener al = new ActionListener() { 
	         public void actionPerformed(ActionEvent e){ 
	            Object obj = e.getSource(); 
	            if (obj == btnAceptar) 
	            	btnAceptarActionPerformed(e); 
	            	pulsaAceptar = true;
	         }
	    };  	
	    btnAceptar.addActionListener(al);
	    setVisible(true);
	}
 
	private void btnAceptarActionPerformed(ActionEvent e){
		if (rdbtnRojo.isSelected()){
			color = Colores.Rojo; 
		}
		if (rdbtnAmarillo.isSelected()){
			color = Colores.Amarillo; 
		}
		if (rdbtnAzul.isSelected()){
			color = Colores.Azul; 
		}
		if (rdbtnVerde.isSelected()){
			color = Colores.Verde; 
		}
		if (rdbtnBlanco.isSelected()){
			color = Colores.Blanco; 
		}
		if (rdbtnNegro.isSelected()){
			color = Colores.Negro; 
		}
		if(color==Colores.Auxiliar){
			JOptionPane.showMessageDialog(this,"Elige un color","Elige un color",JOptionPane.WARNING_MESSAGE );
		}
		else dispose();	
	}
	
	public void ponListaColores(Colores c){
		if((c!=null)&&(!listaColores.contains(c)))
			listaColores.add(c);		
	}

	public Colores dameColor(){
		return color;
	}
	
	public boolean pulsaAceptar(){
		return pulsaAceptar;
	}

	public void bloquearBotones(){
		SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                if(listaColores.contains(Colores.Amarillo))
                	rdbtnAmarillo.setEnabled(false);
                if(listaColores.contains(Colores.Azul))
                	rdbtnAzul.setEnabled(false);
                if(listaColores.contains(Colores.Blanco))
                	rdbtnBlanco.setEnabled(false);
                if(listaColores.contains(Colores.Negro))
                	rdbtnNegro.setEnabled(false);
                if(listaColores.contains(Colores.Rojo))
                	rdbtnRojo.setEnabled(false);
                if(listaColores.contains(Colores.Verde))
                	rdbtnVerde.setEnabled(false);
           } 
        });
	}
}
