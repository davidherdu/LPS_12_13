package es.ucm.fdi.lps.g08;

public enum Capucha {con_capucha,sin_capucha}
