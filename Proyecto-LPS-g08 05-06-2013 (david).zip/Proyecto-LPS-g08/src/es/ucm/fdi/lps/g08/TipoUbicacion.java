package es.ucm.fdi.lps.g08;

public enum TipoUbicacion {cartas_de_sospechoso,monjes_tachados}
	