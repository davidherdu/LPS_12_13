package es.ucm.fdi.lps.g08.vistaGUI;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelDerecho extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	
	
	
	public PanelDerecho() {
		setLayout(null);
		
		
		
		
		
		
		
		
		

	}

}
