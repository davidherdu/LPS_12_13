package es.ucm.fdi.lps.g08.vistaGUI;

import javax.swing.JPanel;

public class PanelInferior extends JPanel {

	/**
	 * Create the panel.
	 */
	public PanelInferior() {

	}

}
