package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import es.ucm.fdi.lps.g08.TipoRasgo;
import es.ucm.fdi.lps.g08.TipoUbicacion;


public class elegirPreguntas extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private ButtonGroup grupoBotones;
	private JButton btnAceptar;
	private JRadioButton rdbtnPregunta1,rdbtnPregunta2;
	private boolean pulsaAceptar;
	private String pregunta;
	private InterfazPreguntas ip;
	private int tipo;
	
	public elegirPreguntas() {
		super("Elige un tipo de pregunta");
		pulsaAceptar = false;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//No permite Maximizar la ventana
		setResizable(false);
		setBounds(100, 100, 356, 199);
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.setBounds(103, 104, 89, 23);
		panel.add(btnAceptar);
		if(btnAceptar.isSelected()){
			dispose();
		}
		
		//listaColores = c;
		tipo = 0;
		
		grupoBotones = new ButtonGroup();

		rdbtnPregunta1 = new JRadioButton("�Cuantos monjes con rasgoX tienes en ubicacionY?");
		rdbtnPregunta1.setBounds(6, 30, 338, 23);
		panel.add(rdbtnPregunta1);
		grupoBotones.add(rdbtnPregunta1);
					
		rdbtnPregunta2 = new JRadioButton("�Tienes al monjeX en ubicacionY?");
		rdbtnPregunta2.setBounds(6, 59, 338, 23);
		panel.add(rdbtnPregunta2);
		grupoBotones.add(rdbtnPregunta2);
			
		ActionListener al = new ActionListener() { 
	         public void actionPerformed(ActionEvent e){ 
	            Object obj = e.getSource(); 
	            if (obj == btnAceptar) 
	            	btnAceptarActionPerformed(e); 
	            	pulsaAceptar = true;
	         }
	    };  	
	    btnAceptar.addActionListener(al);
	    setVisible(true);
	}
 
	private void btnAceptarActionPerformed(ActionEvent e){
		if (rdbtnPregunta1.isSelected()){
			tipo = 1;
			pregunta = rdbtnPregunta1.getText();
			ip = new InterfazPreguntas();
			ip.setVisible(true);
			ip.preguntaTipo1();
			
		}
		if (rdbtnPregunta2.isSelected()){
			tipo = 2;
			pregunta = rdbtnPregunta2.getText();
			ip = new InterfazPreguntas();
			ip.setVisible(true);
			ip.preguntaTipo2();
		}
		else dispose();	
	}
	
	public void cerrar(){
		ip.dispose();
	}
	
	public TipoUbicacion dameUbicacion(){
		return ip.dameTipoUbicacion();
	}
	
	public TipoRasgo dameRasgo(){
		return ip.dameTipoRasgo();
	}
		
	public String dameCaracteristica(){
		return ip.dameCaracteristica();
	}
	
	public boolean pulsaAceptar(){
		return ip.dameAceptar();
	}
	
	public int dameTipo(){
		return tipo;
	}
	
	public String damePregunta(){
		return ip.pregunta();
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					elegirPreguntas frame = new elegirPreguntas();
					//frame.creaVentana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
