package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class EligePropiedad extends JFrame implements ItemListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> comboCaracteristicas;
	private JButton btnAceptar;
	private JLabel lblpropiedad;
	private String propiedad;
	private boolean aceptar;
	
	public EligePropiedad(){
		super("Elige una propiedad");
		/*SwingUtilities.invokeLater(new Runnable(){
            public void run(){
				setResizable(false);
				setSize(331, 154);
				setLocationRelativeTo(null);
				getContentPane().setLayout(null);
				setVisible(true);
				propiedad = null;
				aceptar = false;
				
				lblpropiedad = new JLabel("Elige una propiedad");
				lblpropiedad.setBounds(10, 11, 127, 14);
				getContentPane().add(lblpropiedad);
				
				comboCaracteristicas = new JComboBox<String>();
				comboCaracteristicas.setBounds(168, 8, 147, 20);
				comboCaracteristicas.setModel(new DefaultComboBoxModel<String>(new String[] {"Padres","Hermanos","Novicios","Templarios","Benedictinos","Franciscano","Con capucha","Sin capucha","Con barba","Afeitado","Gordo","Delgado"}));
				
				getContentPane().add(comboCaracteristicas);
				
				btnAceptar = new JButton("Aceptar");
				btnAceptar.setBounds(96, 71, 89, 23);
				getContentPane().add(btnAceptar);
				
				ActionListener al = new ActionListener() { 
			         public void actionPerformed(ActionEvent e){ 
			            Object obj = e.getSource(); 
			            if (obj == btnAceptar) 
			            	btnAceptarActionPerformed(e); 
			         }
			    };  	
			    btnAceptar.addActionListener(al);
            };
	       });
		comboCaracteristicas.addItemListener(this);*/
	}
	
	public String damePropiedad(){
		SwingUtilities.invokeLater(new Runnable(){
            public void run(){
				setResizable(false);
				setSize(331, 154);
				setLocationRelativeTo(null);
				getContentPane().setLayout(null);
				setVisible(true);
				propiedad = null;
				aceptar = false;
				
				lblpropiedad = new JLabel("Elige una propiedad");
				lblpropiedad.setBounds(10, 11, 127, 14);
				getContentPane().add(lblpropiedad);
				
				comboCaracteristicas = new JComboBox<String>();
				comboCaracteristicas.setBounds(168, 8, 147, 20);
				comboCaracteristicas.setModel(new DefaultComboBoxModel<String>(new String[] {"Padres","Hermanos","Novicios","Templarios","Benedictinos","Franciscano","Con capucha","Sin capucha","Con barba","Afeitado","Gordo","Delgado"}));
				
				getContentPane().add(comboCaracteristicas);
				
				btnAceptar = new JButton("Aceptar");
				btnAceptar.setBounds(96, 71, 89, 23);
				getContentPane().add(btnAceptar);
				
				ActionListener al = new ActionListener() { 
			         public void actionPerformed(ActionEvent e){ 
			            Object obj = e.getSource(); 
			            if (obj == btnAceptar) 
			            	btnAceptarActionPerformed(e); 
			         }
			    };  	
			    btnAceptar.addActionListener(al);
            };
	       });
		comboCaracteristicas.addItemListener(this);
		return propiedad;
	}
	
	private void btnAceptarActionPerformed(ActionEvent e){
			if(propiedad!=null)
				dispose();
	}
	
	public String damePropiedad1(){
		return propiedad;
	}

	public boolean dameAcpetar(){
		return aceptar;
	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==comboCaracteristicas) {
			propiedad = (String)comboCaracteristicas.getSelectedItem();
        }
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new EligePropiedad();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
