package es.ucm.fdi.lps.g08;

public enum Colores {Rojo,Azul,Amarillo,Verde,Blanco,Negro,Auxiliar}
