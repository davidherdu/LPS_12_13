package es.ucm.fdi.lps.g08.EventosEstancias;

public class Scriptorium {

}
