package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import es.ucm.fdi.lps.g08.Colores;
import es.ucm.fdi.lps.g08.Jugador;

public class Opciones extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private ButtonGroup grupoBotones;
	private JButton btnAceptar;
	private boolean pulsaAceptar;
	private ArrayList<JRadioButton> opciones;
	private ArrayList<Jugador> arrayJug;
	private String colorJugador;
	
	public Opciones(String texto) {
		super(texto);
		pulsaAceptar = false;
		opciones = new ArrayList<JRadioButton>();
		arrayJug = new ArrayList<Jugador>();
	}
	
	public void creaVentana(final ArrayList<Jugador> aux){
		SwingUtilities.invokeLater(new Runnable(){  
            public void run(){  
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				//No permite Maximizar la ventana
				setResizable(false);
				setBounds(100, 100, 216, 315);
				panel = new JPanel();
				panel.setBorder(new EmptyBorder(5, 5, 5, 5));
				setContentPane(panel);
				panel.setLayout(null);
				
				btnAceptar = new JButton("Aceptar");
				btnAceptar.setBounds(56, 215, 89, 23);
				panel.add(btnAceptar);
				if(btnAceptar.isSelected()){
					dispose();
				}
		
				//ponOpciones(aux);
				grupoBotones = new ButtonGroup();	
				arrayJug = aux;
				int i = 0;
				int cont = 0;
				while(i<arrayJug.size()){
					JRadioButton rb = new JRadioButton(arrayJug.get(i).getColor().toString());
					opciones.add(rb);
					rb.setBounds(55, 29+cont, 109, 23);
					panel.add(rb);
					grupoBotones.add(rb);
					i++;
					cont = cont + 23;
				}
				
				ActionListener al = new ActionListener() { 
			         public void actionPerformed(ActionEvent e){ 
			            Object obj = e.getSource(); 
			            if (obj == btnAceptar) 
			            	btnAceptarActionPerformed(e); 
			            	pulsaAceptar = true;
			         }	
			    };  	
			    btnAceptar.addActionListener(al);
			    setVisible(true);
            }  
        }); 
	}
	
	private void btnAceptarActionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int i = 0;
		while(i<opciones.size()){
			if(opciones.get(i).isSelected()){
				colorJugador = opciones.get(i).getText();
				pulsaAceptar = true;
				dispose();
			}
			i++;
		}
	}
 
	public void ponOpciones(final ArrayList<Jugador> aux){
		SwingUtilities.invokeLater(new Runnable(){  
            public void run(){   
				grupoBotones = new ButtonGroup();	
				arrayJug = aux;
				int i = 0;
				int cont = 0;
				while(i<arrayJug.size()){
					JRadioButton rb = new JRadioButton(arrayJug.get(i).getColor().toString());
					opciones.add(rb);
					rb.setBounds(55, 29+cont, 109, 23);
					panel.add(rb);
					grupoBotones.add(rb);
					i++;
					cont = cont + 23;
				}
            }  
        }); 
	}
	
	public String dameJugador(){
		return colorJugador;
	}
	
	public boolean pulsaAceptar(){
		return pulsaAceptar;
	}
}
