package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import es.ucm.fdi.lps.g08.*;
import es.ucm.fdi.lps.g08.cliente.MedioControlador;

import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterfazInicio extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2680152776020910907L;
	private JPanel contentPane;
	private Image imgInicio = (Toolkit.getDefaultToolkit()).getImage("img/AbadiaInicio.png");
	private PanelTablero panelSuperior;
	private String bienvenida;
	private JButton btnSalir,btnJugar,btnElegircolor;
	private boolean turno,jugar;
	private Colores color = null;
	private elegirColores ec;
	private Jugador jugador;
	private ArrayList<Colores> listaColores;
	private int numJugador;
	private InterfazPrincipal intPrin;
	private MedioControlador controlador = null;
	
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfazInicio frame = new InterfazInicio(1,new Vista(),new Jugador(Colores.Amarillo));
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/
	
	/**
	 * Create the frame.
	 */
	public InterfazInicio() {
		super("El Misterio de la Abadia.");// Jugador "+i);
		SwingUtilities.invokeLater(new Runnable(){  
            public void run(){   
			//jugador = j;
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			//No permite Maximizar la ventana
			setResizable(false);
			setBounds(100, 100, 684, 479);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			//numJugador = i;
	
			jugar = false;
			listaColores = new ArrayList<Colores>();
			ec = new elegirColores();
			
			//PanelSuperior
			panelSuperior = new PanelTablero(imgInicio);
			
			panelSuperior.setBounds(6, 6, 414, 376);
			contentPane.add(panelSuperior);
			panelSuperior.setLayout(null);		
			
			//PanelInferior
			JPanel panelInferior = new JPanel();
			panelInferior.setBounds(6, 394, 414, 58);
			contentPane.add(panelInferior);
			panelInferior.setLayout(null);
			
			btnElegircolor = new JButton("ELEGIR COLOR");
			btnElegircolor.setBounds(23, 23, 127, 29);
			panelInferior.add(btnElegircolor);
			
			btnSalir = new JButton("SALIR");
			btnSalir.setBounds(291, 23, 117, 29);
			panelInferior.add(btnSalir);
	
			btnJugar = new JButton("JUGAR");
			btnJugar.setBounds(162, 23, 117, 29);
			panelInferior.add(btnJugar);
			btnJugar.setEnabled(false);
			
			btnElegircolor.setEnabled(false);
			btnSalir.setEnabled(false);
								
			//Panel Derecho
			Vista v = new Vista();
			bienvenida = v.InterfazInicio();
			
			JEditorPane txtpnD = new JTextPane();
			txtpnD.setToolTipText("");
			txtpnD.setText(bienvenida);
			txtpnD.setEnabled(true);
			txtpnD.setEditable(false);
			txtpnD.setOpaque(false);
			txtpnD.setFont(new Font("Arial", Font.PLAIN, 14));
			txtpnD.setForeground(Color.DARK_GRAY);
		
			txtpnD.setBounds(432, 6, 246, 446);
			contentPane.add(txtpnD);	
	
			ActionListener al = new ActionListener() { 
		         public void actionPerformed(ActionEvent e){ 
		            Object obj = e.getSource(); 
		            if (obj == btnSalir) 
		            	btnSalirActionPerformed(e); 
		            else if (obj == btnElegircolor) 
		            	btnElegircolorActionPerformed(e); 
		           else if (obj == btnJugar) 
		        	   btnJugarActionPerformed(e);
		       
		         } 
		      };
		      
		    //a|adimos oyentes
		      btnSalir.addActionListener(al);
		      btnJugar.addActionListener(al);
		      btnElegircolor.addActionListener(al);	
            }  
        });
	}//Fin Constructor InterfazInicio
	
	public void ponControlador(MedioControlador controlador){
        if (controlador == null)
            throw new IllegalArgumentException("No se puede poner un medio controlador de cliente nulo a la vista.");        
        this.controlador = controlador;
    }
	
	public void ponIDJugador(final Jugador j,final int i){
        if (j == null)
            throw new IllegalArgumentException("No se puede poner una ID de un jugador nulo en la vista.");        
        jugador = j;
        numJugador = i;
    }
	
	//Action Performed para Opcion Salir
	private void btnSalirActionPerformed(ActionEvent e){ 
		int res = JOptionPane.showConfirmDialog( this,"�Desea Salir del Juego?","Salir",JOptionPane.YES_NO_OPTION );
	    if( res == JOptionPane.YES_OPTION )
	      	  dispose();
	} //fin opcion salir
	
	//Action Performed para Opcion Elegir Color
	private void btnElegircolorActionPerformed(ActionEvent e){ 
		int res = JOptionPane.showConfirmDialog( this,"�Desea elegir el color?","Elige Color",JOptionPane.YES_NO_OPTION );   
		if( res == JOptionPane.YES_OPTION ){			          	
      	  //ec = new elegirColores(listaColores);
          	SwingUtilities.invokeLater(new Runnable(){  
                public void run(){   
                	//btnJugar.setEnabled(true);
                	ec.creaVentana();
                	btnElegircolor.setEnabled(false);
                }  
            });
      	  //color = ec.dameColor();
      	  contentPane.setVisible(true);
		}
	} //fin opcion ElegirColor
	
	//Action Performed para Opcion Jugar
	private void btnJugarActionPerformed(ActionEvent e){ 
		int res = JOptionPane.showConfirmDialog( this,"�Desea Empezar el Juego?","Jugar",JOptionPane.YES_NO_OPTION );    
        if( res == JOptionPane.YES_OPTION ){	 
    	  SwingUtilities.invokeLater(new Runnable(){  
                public void run(){               	  
                  intPrin = new InterfazPrincipal(listaColores,jugador,color,numJugador);
  	        	  intPrin.setVisible(true);
  	        	  contentPane.setVisible(false);
  	        	  jugar = true;
  	        	  intPrin.ponControlador(controlador);
  	        	  dispose();
                }  
            });  
       }	   
	} //fin opcion Jugar
			
	public void turno(boolean t){
		turno = t;
		SwingUtilities.invokeLater(new Runnable(){  
            public void run(){   	
        		if(turno){
        			btnElegircolor.setEnabled(true);
        			btnSalir.setEnabled(true);
        		}
            }  
        });
	}
	
	public void jugar(){
		SwingUtilities.invokeLater(new Runnable(){
            public void run(){
            	btnJugar.setEnabled(true);
         };
       });
	}
	
	public void ponListaColores(final Colores c){
		if(c!=null){
		  ec.ponListaColores(c);
		  if(!listaColores.contains(c))
			  listaColores.add(c);
		}
	}
	
	public Colores dameColor(){
		color = ec.dameColor();
		while(color==null)
			color = ec.dameColor();
		return color;
	}
	
	public boolean dameJugar(){
		return jugar;
	}
	
	public InterfazPrincipal dameInterfazPrincipal(){
		return intPrin;
	}
	
	/*public void setListaColores(ArrayList<Colores> c){
		listaColores = c;
	}*/
	
	public boolean pulsaAceptar(){
		return ec.pulsaAceptar();
	}

}
