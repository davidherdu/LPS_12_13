package es.ucm.fdi.lps.g08;

public enum Complexion{gordo,delgado}
