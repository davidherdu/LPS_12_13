package es.ucm.fdi.lps.g08;

public enum Titulo{padre,hermano,novicio}
