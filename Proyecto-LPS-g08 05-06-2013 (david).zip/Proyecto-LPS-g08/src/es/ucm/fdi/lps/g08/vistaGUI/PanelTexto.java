package es.ucm.fdi.lps.g08.vistaGUI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.JScrollBar;
import java.awt.Color;

public class PanelTexto extends JFrame{
	private JButton btnAceptar;
	private JPanel panel;
	private JTextArea textArea;
	
	public PanelTexto(final String texto) {
    	SwingUtilities.invokeLater(new Runnable(){  
            public void run(){   
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setSize(400,400);
				setLocationRelativeTo(null);
				setResizable(false);
				setVisible(true);
				
				panel = new JPanel();
				getContentPane().add(panel, BorderLayout.CENTER);
				panel.setLayout(null);
				
				btnAceptar = new JButton("Aceptar");
				btnAceptar.setBounds(156, 296, 89, 23);
				panel.add(btnAceptar);
				
				textArea = new JTextArea(texto);
				textArea.setEditable(false);
				textArea.setBounds(10, 11, 374, 261);
				panel.add(textArea);
				
				JScrollPane scrollBar = new JScrollPane(textArea);
				scrollBar.setForeground(new Color(128, 128, 128));
				scrollBar.setBackground(new Color(128, 128, 128));
				scrollBar.setBounds(10, 11, 374, 261);
				panel.add(scrollBar);
				
				ActionListener al = new ActionListener() { 
			         public void actionPerformed(ActionEvent e){ 
			            Object obj = e.getSource(); 
			            if (obj == btnAceptar) 
			            	btnAceptarActionPerformed(e); 
			         } 
			      };
			    btnAceptar.addActionListener(al);
            }  
        });
	}
	
	private void btnAceptarActionPerformed(ActionEvent e){ 
		dispose();
	} 
}
