package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.Image;

import javax.swing.JPanel;

import java.awt.Graphics;
//import java.awt.Image;


import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;


public class PanelCarta extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Create the panel.
	 */
	Image imagen,ficha;
	
	
	public PanelCarta(String nombreImagen) {
	        if (nombreImagen != null) {
	            imagen = new ImageIcon(
	                           getClass().getResource(nombreImagen)
	                           ).getImage();
	        }
	    }
	 
	/**
	 * @wbp.parser.constructor
	 */
	public PanelCarta(Image imagenInicial) {
		setLayout(null);
	    if (imagenInicial != null) {
	        imagen = imagenInicial;
	    }
	}
	
	public void ponFicha(){
		
	}
	 
	public void setImagen(String nombreImagen) {
	        if (nombreImagen != null) {
	            ficha = new ImageIcon(
	                   getClass().getResource(nombreImagen)
	                   ).getImage();
	        } else {
	            ficha = null;
	        }
	 
	        repaint();
	    }
	 
	 public void setImagen(Image nuevaImagen) {
	        ficha = nuevaImagen;
	 
	        repaint();
	    }
	 
	    @Override
	  public void paint(Graphics g) {
	        if (imagen != null) {
	        
	            g.drawImage(imagen, 0, 0,getWidth(),getHeight(), this);
	 
	            setOpaque(false);
	        } else {
	            setOpaque(true);
	        }
	 
	        super.paint(g);
	    }
	}
	

