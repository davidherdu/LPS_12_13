package es.ucm.fdi.lps.g08.vistaGUI;

import es.ucm.fdi.lps.g08.*;
import es.ucm.fdi.lps.g08.cliente.MedioControlador;
import es.ucm.fdi.lps.g08.servidor.MedioControladorCliente;
import es.ucm.fdi.lps.g08.Constantes;

import java.util.*;
import java.awt.EventQueue;

import java.awt.Toolkit;

import javax.print.DocFlavor.URL;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JRadioButtonMenuItem;


public class InterfazPrincipal extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private PanelTablero panelTablero;
	private PanelInferior panelInferior;
	private PanelDerecho panelDerecho;
	private JPanel panelSuperior;
	
	private Image imgMapa = (Toolkit.getDefaultToolkit()).getImage("img/mapa.png");
	private Image imgScriptorium = (Toolkit.getDefaultToolkit()).getImage("img/MazoScriptorium.png");
	private Image imgBiblioteca = (Toolkit.getDefaultToolkit()).getImage("img/MazoBiblioteca.png");
	private Image imgEvento = (Toolkit.getDefaultToolkit()).getImage("img/MazoEvento.png");
	private Image froja= (Toolkit.getDefaultToolkit()).getImage("img/froja.png");
	private Image fverde= (Toolkit.getDefaultToolkit()).getImage("img/fverde.png");
	private Image famarilla= (Toolkit.getDefaultToolkit()).getImage("img/famarilla.png");
	private Image fazul= (Toolkit.getDefaultToolkit()).getImage("img/fazul.png");
	private Image fnegra= (Toolkit.getDefaultToolkit()).getImage("img/fnegra.png");
	private Image fblanca= (Toolkit.getDefaultToolkit()).getImage("img/fblanca.png");
	
	private JMenuBar menuBar;
	private JMenu mArchivo;
	private JMenu mEditar;
	private JMenu mOpciones;
	private JMenu mAyuda;
	private JMenu revAcus, mnNewMenu,mnAcusacion;
	private JMenuItem mnRealizarMov,mnMostrarConfe,mnVerTodosMonjes,mnVerRevelacion,mnVerMonjesTachados,mnVerHojaRasgos,mnVerTusCartas;
	private JMenuItem mnAbout,mnSalir,mnAbrir,mnGuardarComo;
	private Jugador jugador;
	//private JLabel fichajug;
	private ArrayList<Colores> listaColores;
	private ArrayList<JLabel> labelJugadores;
	private int numJugador;
	
	private JButton btnScriptorium,btnNewButton,btnEventos;
	private boolean turno,moverse;
	private Punto punto,puntoAnterior;
	private ArrayList<Room> estancias,todasEstancias;
	private MedioControlador controlador = null;
	private JLabel lblCripta;
	private JLabel lblCapilla;
	private JLabel lblConfInterior;
	private JLabel lblConfExterior;
	private JLabel lblPatio;
	private JLabel lblCeldaAzul;
	private JLabel lblPasilloAzul;
	private JLabel lblScriptorium;
	private JLabel lblBiblioteca;
	private JLabel lblClaustroNorte;
	private JLabel lblClEste;
	private JLabel lblClsur;
	private JLabel lblCloeste;
	private JLabel lblPRojo;
	private JLabel lblCeldaRoja;
	private JLabel lblPNegro;
	private JLabel lblCeldaNegra;
	private JLabel lblSalaCapitular;
	private JLabel lblCeldaAmarilla;
	private JLabel lblPAmarillo;
	private JLabel lblCeldaVerde;
	private JLabel lblPVerde;
	private JLabel lblLocutorio;
	private JLabel lblCeldaBlanca;
	private JLabel lblPBlanco;
	private ArrayList<JLabel> coloresEstancias;
	private String nombreEstancia;
	private boolean pulsado;
	private String revelacion,acusacion;
	private ButtonGroup grupoBotones,grupoBotones2;
	private ArrayList<JRadioButtonMenuItem> arrayAcusacion,arrayRevelacion;
	private String titulo;
	private ArrayList<Jugador> arrayJug;
	private int opcion;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfazPrincipal frame = new InterfazPrincipal(null,null,Colores.Rojo,0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfazPrincipal(ArrayList<Colores> lc,Jugador j,Colores color,int i) {
		
		//titulo de la ventana
		super("El Misterio de la Abadia. Jugador "+color.toString());
		titulo = "El Misterio de la Abadia. Jugador "+color.toString();
		jugador = j;		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//No permite Maximizar la ventana
		setResizable(false);
		
		listaColores = lc;
		numJugador = i;
		coloresEstancias = new ArrayList<JLabel>();
		punto = null;
		puntoAnterior = null;
		pulsado = false;
		todasEstancias = new ArrayList<Room>();
		grupoBotones = new ButtonGroup();
		grupoBotones2 = new ButtonGroup();
		arrayAcusacion = new ArrayList<JRadioButtonMenuItem>();
		arrayRevelacion = new ArrayList<JRadioButtonMenuItem>();
		arrayJug = new ArrayList<Jugador>();
		
		setBounds(100, 100, 696, 725);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setVisible(true);
		
		panelTablero = new PanelTablero(imgMapa);
		panelTablero.setForeground(Color.RED);
		panelTablero.setOpaque(false);
		
		//PanelTablero.panelSuperior;
		panelTablero.setBounds(10, 31, 500, 500);
		contentPane.add(panelTablero);
		panelTablero.setLayout(null);
		
		lblCripta = new JLabel("CRIPTA");
		lblCripta.setForeground(new Color(255, 255, 0));
		lblCripta.setBounds(387, 47, 46, 14);
		panelTablero.add(lblCripta);
		coloresEstancias.add(lblCripta);
		
		lblCapilla = new JLabel("CAPILLA");
		lblCapilla.setForeground(new Color(255, 255, 0));
		lblCapilla.setBounds(304, 24, 61, 14);
		panelTablero.add(lblCapilla);
		coloresEstancias.add(lblCapilla);
		
		lblConfInterior = new JLabel("CONF. INTERIOR");
		lblConfInterior.setForeground(new Color(255, 255, 0));
		lblConfInterior.setBounds(159, 36, 113, 14);
		panelTablero.add(lblConfInterior);
		coloresEstancias.add(lblConfInterior);
		
		lblConfExterior = new JLabel("CONF. EXTERIOR");
		lblConfExterior.setForeground(new Color(255, 255, 0));
		lblConfExterior.setBounds(344, 110, 95, 14);
		panelTablero.add(lblConfExterior);
		coloresEstancias.add(lblConfExterior);
		
		lblPatio = new JLabel("PATIO");
		lblPatio.setForeground(new Color(255, 255, 0));
		lblPatio.setBounds(172, 121, 46, 14);
		panelTablero.add(lblPatio);
		coloresEstancias.add(lblPatio);
		
		lblCeldaAzul = new JLabel("CELDA AZUL");
		lblCeldaAzul.setForeground(new Color(255, 255, 0));
		lblCeldaAzul.setBounds(363, 157, 89, 14);
		panelTablero.add(lblCeldaAzul);
		coloresEstancias.add(lblCeldaAzul);
		
		lblPasilloAzul = new JLabel("P. AZUL");
		lblPasilloAzul.setForeground(new Color(255, 255, 0));
		lblPasilloAzul.setBounds(373, 212, 61, 14);
		panelTablero.add(lblPasilloAzul);
		coloresEstancias.add(lblPasilloAzul);
		
		lblScriptorium = new JLabel("SCRIPTORIUM");
		lblScriptorium.setForeground(new Color(255, 255, 0));
		lblScriptorium.setBounds(363, 246, 90, 14);
		panelTablero.add(lblScriptorium);
		coloresEstancias.add(lblScriptorium);
		
		lblBiblioteca = new JLabel("BIBLIOTECA");
		lblBiblioteca.setForeground(new Color(255, 255, 0));
		lblBiblioteca.setBounds(387, 331, 99, 14);
		panelTablero.add(lblBiblioteca);
		coloresEstancias.add(lblBiblioteca);
		
		lblClaustroNorte = new JLabel("CL. NORTE");
		lblClaustroNorte.setForeground(new Color(255, 255, 0));
		lblClaustroNorte.setBounds(210, 227, 78, 14);
		panelTablero.add(lblClaustroNorte);
		coloresEstancias.add(lblClaustroNorte);
		
		lblClEste = new JLabel("CL. ESTE");
		lblClEste.setForeground(new Color(255, 255, 0));
		lblClEste.setBounds(282, 267, 61, 14);
		panelTablero.add(lblClEste);
		coloresEstancias.add(lblClEste);
		
		lblClsur = new JLabel("CL.SUR");
		lblClsur.setForeground(new Color(255, 255, 0));
		lblClsur.setBounds(226, 303, 46, 14);
		panelTablero.add(lblClsur);
		coloresEstancias.add(lblClsur);
		
		lblCloeste = new JLabel("CL.OESTE");
		lblCloeste.setForeground(new Color(255, 255, 0));
		lblCloeste.setBounds(168, 256, 69, 14);
		panelTablero.add(lblCloeste);
		coloresEstancias.add(lblCloeste);
		
		lblPRojo = new JLabel("P. ROJO");
		lblPRojo.setForeground(new Color(255, 255, 0));
		lblPRojo.setBounds(304, 317, 61, 14);
		panelTablero.add(lblPRojo);
		coloresEstancias.add(lblPRojo);
		
		lblCeldaRoja = new JLabel("CELDA ROJA");
		lblCeldaRoja.setForeground(new Color(255, 255, 0));
		lblCeldaRoja.setBounds(374, 398, 78, 14);
		panelTablero.add(lblCeldaRoja);
		coloresEstancias.add(lblCeldaRoja);
		
		lblPNegro = new JLabel("P. NEGRO");
		lblPNegro.setForeground(new Color(255, 255, 0));
		lblPNegro.setBounds(252, 347, 69, 14);
		panelTablero.add(lblPNegro);
		coloresEstancias.add(lblPNegro);
		
		lblCeldaNegra = new JLabel("CELDA NEGRA");
		lblCeldaNegra.setForeground(new Color(255, 255, 0));
		lblCeldaNegra.setBounds(297, 454, 95, 14);
		panelTablero.add(lblCeldaNegra);
		coloresEstancias.add(lblCeldaNegra);
		
		lblSalaCapitular = new JLabel("SALA CAPITULAR");
		lblSalaCapitular.setForeground(new Color(255, 255, 0));
		lblSalaCapitular.setBounds(195, 475, 113, 14);
		panelTablero.add(lblSalaCapitular);
		coloresEstancias.add(lblSalaCapitular);
		
		lblCeldaAmarilla = new JLabel("CELDA AMARILLA");
		lblCeldaAmarilla.setForeground(new Color(255, 255, 0));
		lblCeldaAmarilla.setBounds(64, 442, 113, 14);
		panelTablero.add(lblCeldaAmarilla);
		coloresEstancias.add(lblCeldaAmarilla);
		
		lblPAmarillo = new JLabel("P. AMARILLO");
		lblPAmarillo.setForeground(new Color(255, 255, 0));
		lblPAmarillo.setBounds(138, 347, 89, 14);
		panelTablero.add(lblPAmarillo);
		coloresEstancias.add(lblPAmarillo);
		
		lblCeldaVerde = new JLabel("CELDA VERDE");
		lblCeldaVerde.setForeground(new Color(255, 255, 0));
		lblCeldaVerde.setBounds(10, 377, 89, 14);
		panelTablero.add(lblCeldaVerde);
		coloresEstancias.add(lblCeldaVerde);
		
		lblPVerde = new JLabel("P. VERDE");
		lblPVerde.setForeground(new Color(255, 255, 0));
		lblPVerde.setBounds(30, 303, 69, 14);
		panelTablero.add(lblPVerde);
		coloresEstancias.add(lblPVerde);
		
		lblLocutorio = new JLabel("LOCUTORIO");
		lblLocutorio.setForeground(new Color(255, 255, 0));
		lblLocutorio.setBounds(10, 227, 89, 14);
		panelTablero.add(lblLocutorio);
		coloresEstancias.add(lblLocutorio);
		
		lblCeldaBlanca = new JLabel("CELDA BLANCA");
		lblCeldaBlanca.setForeground(new Color(255, 255, 0));
		lblCeldaBlanca.setBounds(37, 142, 89, 14);
		panelTablero.add(lblCeldaBlanca);
		coloresEstancias.add(lblCeldaBlanca);
		
		lblPBlanco = new JLabel("P. BLANCO");
		lblPBlanco.setForeground(new Color(255, 255, 0));
		lblPBlanco.setBounds(77, 212, 73, 14);
		panelTablero.add(lblPBlanco);
		coloresEstancias.add(lblPBlanco);
		
		moverse = false;
		labelJugadores = new ArrayList<JLabel>();
		/*fichajug = new JLabel();
		fichajug.setText(color.toString());
		ponColorFicha(color);
		fichajug.setBounds(325, 55, 61, 16);
		panelTablero.add(fichajug);*/
		ponerFicha();
		
		
		//Panel Derecho.Mazos
		panelDerecho = new PanelDerecho();
		panelDerecho.setBounds(527, 31, 143, 500);
		contentPane.add(panelDerecho);
		panelDerecho.setLayout(null);
		
		
		ImageIcon iconS= new ImageIcon(imgScriptorium.getScaledInstance(143,97,0));
		btnScriptorium = new JButton(iconS);
		btnScriptorium.setBounds(0, 100, 143, 97);
		panelDerecho.add(btnScriptorium);
		
		ImageIcon iconB= new ImageIcon(imgBiblioteca.getScaledInstance(143,97,0));
		btnNewButton = new JButton(iconB);
		btnNewButton.setBounds(0, 208, 143, 97);
		panelDerecho.add(btnNewButton);
		
		ImageIcon iconE= new ImageIcon(imgEvento.getScaledInstance(143,97,0));
		btnEventos = new JButton(iconE);
		btnEventos.setBounds(0, 316, 143, 97);
		panelDerecho.add(btnEventos);
		
		JLabel lblMazos = new JLabel("MAZOS");
		lblMazos.setForeground(Color.RED);
		lblMazos.setFont(new Font("Tahoma", Font.PLAIN, 42));
		lblMazos.setHorizontalAlignment(SwingConstants.CENTER);
		lblMazos.setBounds(0, 0, 143, 68);
		panelDerecho.add(lblMazos);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 542, 660, 134);
		contentPane.add(scrollPane);
		
		//JButton btnNewButton = new JButton("New button");
		//panelDerecho.add(btnNewButton);
		
		//Panel Inferior.Cartas del jugador
		panelInferior = new PanelInferior();
		scrollPane.setViewportView(panelInferior);
		panelInferior.setLayout(null);

		//PanelSuperior.MENU
		panelSuperior = new JPanel();
		panelSuperior.setBounds(10, 0, 680, 25);
		contentPane.add(panelSuperior);
		panelSuperior.setLayout(null);
		
		menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 674, 25);
		menuBar.setBorderPainted(false);
		panelSuperior.add(menuBar);
		
		//Menu Archivo
		mArchivo = new JMenu("Archivo");
		menuBar.add(mArchivo);

		
		mnAbrir = new JMenuItem("Abrir");
		mArchivo.add(mnAbrir);
		
		mnGuardarComo = new JMenuItem("Guardar Como");
		mArchivo.add(mnGuardarComo);
		
		mnSalir = new JMenuItem("Salir");
		mArchivo.add(mnSalir);
		
		//Menu Editar
		mEditar = new JMenu("Editar");
		menuBar.add(mEditar);
		
		
		JMenuItem mnCortar = new JMenuItem("Cortar");
		mEditar.add(mnCortar);
		
		JMenuItem mnCopiar = new JMenuItem("Copiar");
		mEditar.add(mnCopiar);
		
		JMenuItem mnPegar = new JMenuItem("Pegar");
		mEditar.add(mnPegar);
		
		
		//Menu Opciones
		mOpciones = new JMenu("Opciones");
		menuBar.add(mOpciones);
		
		mnVerTusCartas = new JMenuItem("1. Ver tus cartas de Sospechoso");
		mOpciones.add(mnVerTusCartas);
		
		mnVerHojaRasgos = new JMenuItem("2. Ver tu hoja de rasgos");
		mOpciones.add(mnVerHojaRasgos);
		
		mnVerMonjesTachados = new JMenuItem("3. Ver los monjes que tienes tachados");
		mOpciones.add(mnVerMonjesTachados);
		
		mnVerRevelacion = new JMenuItem("4. Ver revelaciones y acusaciones");
		mOpciones.add(mnVerRevelacion);
		
		mnVerTodosMonjes = new JMenuItem("5. Ver todos los monjes");
		mOpciones.add(mnVerTodosMonjes);
		
		mnRealizarMov = new JMenuItem("6. Realizar un movimiento");
		mOpciones.add(mnRealizarMov);
		mnRealizarMov.setEnabled(false);
		
		mnMostrarConfe = new JMenuItem("7. Mostrar ultimos en confesarse");
		mOpciones.add(mnMostrarConfe);
		
		//Menu revelacion acusacion
		revAcus = new JMenu("Revelacion-Acusacion");
		menuBar.add(revAcus);
		revAcus.setEnabled(false);
		
		mnAcusacion = new JMenu("Acusacion");
		revAcus.add(mnAcusacion);
		mnAcusacion.setEnabled(false);
		
		JMenu mnNewMenu_3 = new JMenu("Franciscanos");
		mnAcusacion.add(mnNewMenu_3);
		
		JRadioButtonMenuItem chckbxmntmGalbraith = new JRadioButtonMenuItem("GALBRAITH");
		mnNewMenu_3.add(chckbxmntmGalbraith);
		grupoBotones.add(chckbxmntmGalbraith);
		arrayAcusacion.add(chckbxmntmGalbraith);
		
		JRadioButtonMenuItem chckbxmntmNewCheckItem_3 = new JRadioButtonMenuItem("MICHAEL");
		mnNewMenu_3.add(chckbxmntmNewCheckItem_3);
		grupoBotones.add(chckbxmntmNewCheckItem_3);
		arrayAcusacion.add(chckbxmntmNewCheckItem_3);
		
		JRadioButtonMenuItem chckbxmntmEmmanuel = new JRadioButtonMenuItem("EMMANUEL");
		mnNewMenu_3.add(chckbxmntmEmmanuel);
		grupoBotones.add(chckbxmntmEmmanuel);
		arrayAcusacion.add(chckbxmntmEmmanuel);
		
		JRadioButtonMenuItem chckbxmntmCuthbert = new JRadioButtonMenuItem("CUTHBERT");
		mnNewMenu_3.add(chckbxmntmCuthbert);
		grupoBotones.add(chckbxmntmCuthbert);
		arrayAcusacion.add(chckbxmntmCuthbert);
		
		JRadioButtonMenuItem chckbxmntmJacques = new JRadioButtonMenuItem("JACQUES");
		mnNewMenu_3.add(chckbxmntmJacques);
		grupoBotones.add(chckbxmntmJacques);
		arrayAcusacion.add(chckbxmntmJacques);
		
		JRadioButtonMenuItem chckbxmntmBartholomew = new JRadioButtonMenuItem("BARTHOLOMEW");
		mnNewMenu_3.add(chckbxmntmBartholomew);
		grupoBotones.add(chckbxmntmBartholomew);
		arrayAcusacion.add(chckbxmntmBartholomew);
		
		JRadioButtonMenuItem chckbxmntmAndre = new JRadioButtonMenuItem("ANDRE");
		mnNewMenu_3.add(chckbxmntmAndre);
		grupoBotones.add(chckbxmntmAndre);
		arrayAcusacion.add(chckbxmntmAndre);
		
		JRadioButtonMenuItem chckbxmntmNicholas = new JRadioButtonMenuItem("NICHOLAS");
		mnNewMenu_3.add(chckbxmntmNicholas);
		grupoBotones.add(chckbxmntmNicholas);
		arrayAcusacion.add(chckbxmntmNicholas);
		
		JMenu mnNewMenu_2 = new JMenu("Benedictinos");
		mnAcusacion.add(mnNewMenu_2);
		
		JRadioButtonMenuItem chckbxmntmBruno = new JRadioButtonMenuItem("BRUNO");
		mnNewMenu_2.add(chckbxmntmBruno);
		grupoBotones.add(chckbxmntmBruno);
		arrayAcusacion.add(chckbxmntmBruno);
		
		JRadioButtonMenuItem chckbxmntmSergio = new JRadioButtonMenuItem("SERGIO");
		mnNewMenu_2.add(chckbxmntmSergio);
		grupoBotones.add(chckbxmntmSergio);
		arrayAcusacion.add(chckbxmntmSergio);
		
		JRadioButtonMenuItem chckbxmntmBerengar = new JRadioButtonMenuItem("BERENGAR");
		mnNewMenu_2.add(chckbxmntmBerengar);
		grupoBotones.add(chckbxmntmBerengar);
		arrayAcusacion.add(chckbxmntmBerengar);
		
		JRadioButtonMenuItem chckbxmntmJulian = new JRadioButtonMenuItem("JULIAN");
		mnNewMenu_2.add(chckbxmntmJulian);
		grupoBotones.add(chckbxmntmJulian);
		arrayAcusacion.add(chckbxmntmJulian);
		
		JRadioButtonMenuItem chckbxmntmCyrille = new JRadioButtonMenuItem("CYRILLE");
		mnNewMenu_2.add(chckbxmntmCyrille);
		grupoBotones.add(chckbxmntmCyrille);
		arrayAcusacion.add(chckbxmntmCyrille);
		
		JRadioButtonMenuItem chckbxmntmCharles = new JRadioButtonMenuItem("CHARLES");
		mnNewMenu_2.add(chckbxmntmCharles);
		grupoBotones.add(chckbxmntmCharles);
		arrayAcusacion.add(chckbxmntmCharles);
		
		JRadioButtonMenuItem chckbxmntmPhilippe = new JRadioButtonMenuItem("PHILIPPE");
		mnNewMenu_2.add(chckbxmntmPhilippe);
		grupoBotones.add(chckbxmntmPhilippe);
		arrayAcusacion.add(chckbxmntmPhilippe);
		
		JRadioButtonMenuItem chckbxmntmGuy = new JRadioButtonMenuItem("GUY");
		mnNewMenu_2.add(chckbxmntmGuy);
		grupoBotones.add(chckbxmntmGuy);
		arrayAcusacion.add(chckbxmntmGuy);
		
		JMenu mnNewMenu_1 = new JMenu("Templarios");
		mnAcusacion.add(mnNewMenu_1);
		
		JRadioButtonMenuItem chckbxmntmMatthew = new JRadioButtonMenuItem("MATTHEW");
		mnNewMenu_1.add(chckbxmntmMatthew);
		grupoBotones.add(chckbxmntmMatthew);
		arrayAcusacion.add(chckbxmntmMatthew);
		
		JRadioButtonMenuItem chckbxmntmWilliam = new JRadioButtonMenuItem("WILLIAM");
		mnNewMenu_1.add(chckbxmntmWilliam);
		grupoBotones.add(chckbxmntmWilliam);
		arrayAcusacion.add(chckbxmntmWilliam);
		
		JRadioButtonMenuItem chckbxmntmFortune = new JRadioButtonMenuItem("FORTUNE");
		mnNewMenu_1.add(chckbxmntmFortune);
		grupoBotones.add(chckbxmntmFortune);
		arrayAcusacion.add(chckbxmntmFortune);
		
		JRadioButtonMenuItem chckbxmntmHarold = new JRadioButtonMenuItem("HAROLD");
		mnNewMenu_1.add(chckbxmntmHarold);
		grupoBotones.add(chckbxmntmHarold);
		arrayAcusacion.add(chckbxmntmHarold);
		
		JRadioButtonMenuItem chckbxmntmMalachi = new JRadioButtonMenuItem("MALACHI");
		mnNewMenu_1.add(chckbxmntmMalachi);
		grupoBotones.add(chckbxmntmMalachi);
		arrayAcusacion.add(chckbxmntmMalachi);
		
		JRadioButtonMenuItem chckbxmntmGerard = new JRadioButtonMenuItem("GERARD");
		mnNewMenu_1.add(chckbxmntmGerard);
		grupoBotones.add(chckbxmntmGerard);
		arrayAcusacion.add(chckbxmntmGerard);
		
		JRadioButtonMenuItem chckbxmntmBasil = new JRadioButtonMenuItem("BASIL");
		mnNewMenu_1.add(chckbxmntmBasil);
		grupoBotones.add(chckbxmntmBasil);
		arrayAcusacion.add(chckbxmntmBasil);
		
		JRadioButtonMenuItem chckbxmntmThomas = new JRadioButtonMenuItem("THOMAS");
		mnNewMenu_1.add(chckbxmntmThomas);
		grupoBotones.add(chckbxmntmThomas);
		arrayAcusacion.add(chckbxmntmThomas);
		
		mnNewMenu = new JMenu("Revelacion");
		revAcus.add(mnNewMenu);
		mnNewMenu.setEnabled(false);
		
		JRadioButtonMenuItem chckbxmntmNewCheckItem = new JRadioButtonMenuItem("Padre");
		mnNewMenu.add(chckbxmntmNewCheckItem);
		grupoBotones2.add(chckbxmntmNewCheckItem);
		arrayRevelacion.add(chckbxmntmNewCheckItem);
		
		JRadioButtonMenuItem chckbxmntmNewCheckItem_2 = new JRadioButtonMenuItem("Hermano");
		mnNewMenu.add(chckbxmntmNewCheckItem_2);
		grupoBotones2.add(chckbxmntmNewCheckItem_2);
		arrayRevelacion.add(chckbxmntmNewCheckItem_2);
		
		JRadioButtonMenuItem chckbxmntmNewCheckItem_1 = new JRadioButtonMenuItem("Novicio");
		mnNewMenu.add(chckbxmntmNewCheckItem_1);
		grupoBotones2.add(chckbxmntmNewCheckItem_1);
		arrayRevelacion.add(chckbxmntmNewCheckItem_1);
		
		JRadioButtonMenuItem chckbxmntmNewCheckItem_4 = new JRadioButtonMenuItem("Benedictino");
		mnNewMenu.add(chckbxmntmNewCheckItem_4);
		grupoBotones2.add(chckbxmntmNewCheckItem_4);
		arrayRevelacion.add(chckbxmntmNewCheckItem_4);
		
		JRadioButtonMenuItem chckbxmntmTemplario = new JRadioButtonMenuItem("Templario");
		mnNewMenu.add(chckbxmntmTemplario);
		grupoBotones2.add(chckbxmntmTemplario);
		arrayRevelacion.add(chckbxmntmTemplario);
		
		JRadioButtonMenuItem chckbxmntmFranciscano = new JRadioButtonMenuItem("Franciscano");
		mnNewMenu.add(chckbxmntmFranciscano);
		grupoBotones2.add(chckbxmntmFranciscano);
		arrayRevelacion.add(chckbxmntmFranciscano);
		
		JRadioButtonMenuItem chckbxmntmConCapucha = new JRadioButtonMenuItem("Con Capucha");
		mnNewMenu.add(chckbxmntmConCapucha);
		grupoBotones2.add(chckbxmntmConCapucha);
		arrayRevelacion.add(chckbxmntmConCapucha);
		
		JRadioButtonMenuItem chckbxmntmSinCapucha = new JRadioButtonMenuItem("Sin Capucha");
		mnNewMenu.add(chckbxmntmSinCapucha);
		grupoBotones2.add(chckbxmntmSinCapucha);
		arrayRevelacion.add(chckbxmntmSinCapucha);
		
		JRadioButtonMenuItem chckbxmntmAfeitado = new JRadioButtonMenuItem("Afeitado");
		mnNewMenu.add(chckbxmntmAfeitado);
		grupoBotones2.add(chckbxmntmAfeitado);
		arrayRevelacion.add(chckbxmntmAfeitado);
		
		JRadioButtonMenuItem chckbxmntmConBarba = new JRadioButtonMenuItem("Con Barba");
		mnNewMenu.add(chckbxmntmConBarba);
		grupoBotones2.add(chckbxmntmConBarba);
		arrayRevelacion.add(chckbxmntmConBarba);
		
		JRadioButtonMenuItem chckbxmntmGordo = new JRadioButtonMenuItem("Gordo");
		mnNewMenu.add(chckbxmntmGordo);
		grupoBotones2.add(chckbxmntmGordo);
		arrayRevelacion.add(chckbxmntmGordo);
		
		JRadioButtonMenuItem chckbxmntmDelgado = new JRadioButtonMenuItem("Delgado");
		mnNewMenu.add(chckbxmntmDelgado);
		grupoBotones2.add(chckbxmntmDelgado);
		arrayRevelacion.add(chckbxmntmDelgado);
		
		mAyuda = new JMenu("Ayuda");
		menuBar.add(mAyuda);
		
		mnAbout = new JMenuItem("About");
		mAyuda.add(mnAbout);

		opcion = 0;
		
		 ActionListener al = new ActionListener() { 
	         public void actionPerformed(ActionEvent e){ 
	            Object obj = e.getSource(); 
	            if (obj == mnRealizarMov) 
	               btnRealizaMovActionPerformed(e); 
	            else if (obj == mnAbrir) 
	               btnmnAbrirActionPerformed(e); 
	           else if (obj == mnAbout) 
	               btnmAyudaActionPerformed(e);
	           else if (obj== mnSalir)
	        	   btnmnSalirActionPerformed(e);
	           else if (obj== mnGuardarComo)
	        	   btnmnGuardarComoActionPerformed(e);
	           else if(obj==mnMostrarConfe)
	        	   btnMostrarConfeActionPerformed(e);
	           else if(obj==mnVerTodosMonjes)
	        	   btnVerTodosMonjesActionPerformed(e);
	           else if(obj==mnVerRevelacion)
	        	   btnVerRevelacionActionPreformed(e);
	           else if(obj==mnVerMonjesTachados)
	        	   btnVerMonjesTachadosActionPerformed(e);
	           else if(obj==mnVerHojaRasgos)
	        	   btnVerHojasRasgosActionPerformed(e);
	           else if(obj==mnVerTusCartas)
	        	   btnVerTusCartasActionPerformed(e);
	         } 
	      };
	      
	      estancias = new ArrayList<Room>();
      
	      mnRealizarMov.addActionListener(al); 
	      mnAbrir.addActionListener(al);
	      mnSalir.addActionListener(al);
	      mnGuardarComo.addActionListener(al);
	      mnAbout.addActionListener(al);
	      mnMostrarConfe.addActionListener(al);
	      mnVerTodosMonjes.addActionListener(al);
	      mnVerMonjesTachados.addActionListener(al);
	      mnVerHojaRasgos.addActionListener(al);
	      mnVerTusCartas.addActionListener(al);
	      //btnEntrada.addActionListener(al); 
	      //btnConfirma.addActionListener(al); 

	      //Listener del raton
	      PanelMouseListener mouse = new PanelMouseListener();
		  addMouseListener(mouse);
		  addMouseMotionListener(mouse);	
		  //panelTablero.setImagen(famarilla);
	   } //fin constructor interfaz grafica
	
		public void ponControlador(MedioControlador controlador){
	        if (controlador == null)
	            throw new IllegalArgumentException("No se puede poner un medio controlador de cliente nulo a la vista.");        
	        this.controlador = controlador;
	    }

		//Action Performed para Opcion RealizarMovimiento
		private void btnRealizaMovActionPerformed(ActionEvent evt){  
			JOptionPane.showMessageDialog(this, "Por favor, haga click en la casilla a la que quieras moverte", "Realizar Movimiento", JOptionPane.INFORMATION_MESSAGE);
			opcion = 6;
		} 
		
		//Action Performed para Opcion Abrir
		private void btnmnAbrirActionPerformed(ActionEvent e){ 
			new JFileChooser().showDialog( contentPane,"Abrir" );
		} 
		
		//Action Performed para Opcion Abrir
		private void btnmnGuardarComoActionPerformed(ActionEvent e){ 
			new JFileChooser().showSaveDialog(contentPane);
		} 
		
		//Action Performed para Opcion Ayuda
		private void btnmAyudaActionPerformed(ActionEvent e){ 
			Vista vista = new Vista();
			String Ayuda = vista.mensajeAyuda();
			JOptionPane.showMessageDialog(this, Ayuda , "Ayuda", JOptionPane.INFORMATION_MESSAGE);
		} 
		
		//Action Performed para Opcion Salir
		private void btnmnSalirActionPerformed(ActionEvent e){ 
			int res = JOptionPane.showConfirmDialog( this,"�Desea Salir del Juego?",
		              "Salir",JOptionPane.YES_NO_OPTION );
		       
		          if( res == JOptionPane.YES_OPTION )
		          	  dispose();
		} //fin opcion salir
		
		private void btnMostrarConfeActionPerformed(ActionEvent e){
			opcion = 7;
		}

		private void btnVerTodosMonjesActionPerformed(ActionEvent e){
			opcion = 5;
		}
		
		private void btnVerRevelacionActionPreformed(ActionEvent e){
			opcion = 4;
		}
		
		private void btnVerMonjesTachadosActionPerformed(ActionEvent e){
			opcion = 3;
		}
		
		private void btnVerHojasRasgosActionPerformed(ActionEvent e){
			opcion = 2;
		}
		
		private void btnVerTusCartasActionPerformed(ActionEvent e){
			opcion = 1;
		}
		
		public int dameOpcion(){
			return opcion;
		}
		
		public void ponOpcionACero(){
			opcion = 0;
		}
		
		/*private void btnEntradaActionPerformed(ActionEvent evt) { 
			// Centro del marco por omisi�n 
			String nombre = JOptionPane.showInputDialog(null, "Ingrese su nombre por favor"); 
			if (nombre != null && !nombre.isEmpty()) 
				lblNombre.setText("Hola, " + nombre); 
		} 

		private void btnConfirmaActionPerformed(ActionEvent evt){ 
			int respuesta = JOptionPane.showConfirmDialog(this, "�Est� seguro que desea salir?", "Confirmar salida", JOptionPane.YES_NO_OPTION); 
			if (respuesta == 0) 
				System.exit(0); 
		} */

	public void ponerTiulo(String texto){
		setTitle(titulo + texto);
	}
		
	public void ponColorFicha(final Colores c,final JLabel fichajug){
		SwingUtilities.invokeLater(new Runnable(){
            public void run(){
            	if (c==Colores.Rojo){
            		//fichajug.setBackground(Color.RED);
            		fichajug.setForeground(Color.RED);
            		}
            	else if (c==Colores.Azul){
            		//fichajug.setBackground(Color.BLUE);
            		fichajug.setForeground(Color.BLUE);
            		}
            	else if (c==Colores.Verde){
            		//fichajug.setBackground(Color.GREEN);
            		fichajug.setForeground(Color.GREEN);
            		}
            	else if (c==Colores.Amarillo){
            		//fichajug.setBackground(Color.YELLOW);
            		fichajug.setForeground(Color.YELLOW);
            		}
            	else if (c==Colores.Negro){
            		//fichajug.setBackground(Color.BLACK);
            		fichajug.setForeground(Color.BLACK);
            		}
            	else if (c==Colores.Blanco){
            		fichajug.setForeground(Color.WHITE);
            		//fichajug.setBackground(Color.WHITE);
            		}	
         };
       });
	}
	
	public void ponerFicha(){
		SwingUtilities.invokeLater(new Runnable(){
            public void run(){
				int i = 0;
				for(Colores c : listaColores){
					JLabel fichajug = new JLabel();
					fichajug.setText(c.toString());
					labelJugadores.add(fichajug);
				}
				
				for(Colores c : listaColores){
					ponColorFicha(c,labelJugadores.get(i));
					//fichajug.setIcon(new javax.swing.ImageIcon(getClass().getResource("img/famarilla.png")));
					//264,142,329,175
					labelJugadores.get(i).setBounds(264-i*20, 120-i*20, 61+i*20, 16+i*20);
					panelTablero.add(labelJugadores.get(i));
					i++;
				}
            };
	       });
	}
	
	public void ponerFicha(String nombreImagen) {
        if (nombreImagen != null) {
            famarilla = new ImageIcon(getClass().getResource(nombreImagen)).getImage();
        }
    }
	
	public void paint(Graphics g) {
        if (famarilla != null) {
            g.drawImage(famarilla, 325, 55,getWidth(),getHeight(), this);
            panelTablero.setOpaque(false);
        } else {
            panelTablero.setOpaque(true);
        }
        super.paint(g);
    }
	
	public void setTurno(boolean t){
		turno = t;
	}
	
	public void activaMovimiento(){
		mnRealizarMov.setEnabled(true);
	}
	
	public Punto getPunto(){
		return punto;
	}
	
	public void ponJugador(final Punto p,final int i){
		SwingUtilities.invokeLater(new Runnable(){
            public void run(){
            	labelJugadores.get(i).setBounds(p.getX()-12, p.getY()-62, 60, 30);
            };
	       });
	}
	
	public void puedeMoverse(boolean m){
		moverse = m;
	}
	
	public void todasLasEstancias(Room r){
		todasEstancias.add(r);
	}
	
	public void estanciasPosibles(Room r){
		//r.setPosible(true);
		estancias.add(r);
	}
	
	public ArrayList<Room> damePosibles(){
		return estancias;
	}
	
	public void cambiaColoresInicio(){
		int i = 0;
		while(i<coloresEstancias.size()){
			coloresEstancias.get(i).setForeground(new Color(255,255,0));
			i++;
		}
	}
	
	public void cambiaColores(){
		int i = 0;
		Room r = null;
		String nombre = "";
		while(i<estancias.size()){
			r = estancias.get(i);
			nombre = r.getNombre();
			switch(nombre){
			case Constantes.CRIPTA:
				lblCripta.setForeground(Color.CYAN);
				break;
			case Constantes.CAPILLA:
				lblCapilla.setForeground(Color.CYAN);
				break;
			case Constantes.CONFESIONARIO_INTERIOR:
				lblConfInterior.setForeground(Color.CYAN);
				break;
			case Constantes.CONFESIONARIO_EXTERIOR:
				lblConfExterior.setForeground(Color.CYAN);
				break;
			case Constantes.PATIO:
				lblPatio.setForeground(Color.CYAN);
				break;
			case Constantes.CELDA_AZUL:
				lblCeldaAzul.setForeground(Color.CYAN);
				break;
			case Constantes.PASILLO_AZUL:
				lblPasilloAzul.setForeground(Color.CYAN);
				break;
			case Constantes.SCRIPTORIUM:
				lblScriptorium.setForeground(Color.CYAN);
				break;
			case Constantes.BIBLIOTECA:
				lblBiblioteca.setForeground(Color.CYAN);
				break;
			case Constantes.CLAUSTRO_NORTE:
				lblClaustroNorte.setForeground(Color.CYAN);
				break;
			case Constantes.CLAUSTRO_ESTE:
				lblClEste.setForeground(Color.CYAN);
				break;
			case Constantes.CLAUSTRO_SUR:
				lblClsur.setForeground(Color.CYAN);
				break;
			case Constantes.CLAUSTRO_OESTE:
				lblCloeste.setForeground(Color.CYAN);
				break;
			case Constantes.PASILLO_ROJO:
				lblPRojo.setForeground(Color.CYAN);
				break;
			case Constantes.CELDA_ROJA:
				lblCeldaRoja.setForeground(Color.CYAN);
				break;
			case Constantes.PASILLO_NEGRO:
				lblPNegro.setForeground(Color.CYAN);
				break;
			case Constantes.CELDA_NEGRA:
				lblCeldaNegra.setForeground(Color.CYAN);
				break;
			case Constantes.SALA_CAPITULAR:
				lblSalaCapitular.setForeground(Color.CYAN);
				break;
			case Constantes.CELDA_AMARILLA:
				lblCeldaAmarilla.setForeground(Color.CYAN);
				break;
			case Constantes.PASILLO_AMARILLO:
				lblPAmarillo.setForeground(Color.CYAN);
				break;
			case Constantes.CELDA_VERDE:
				lblCeldaVerde.setForeground(Color.CYAN);
				break;
			case Constantes.PASILLO_VERDE:
				lblPVerde.setForeground(Color.CYAN);
				break;
			case Constantes.LOCUTORIO:
				lblLocutorio.setForeground(Color.CYAN);
				break;
			case Constantes.PASILLO_BLANCO:
				lblPBlanco.setForeground(Color.CYAN);
				break;
			case Constantes.CELDA_BLANCA:
				lblCeldaBlanca.setForeground(Color.CYAN);
				break;
			default:
				break;	
			}
			i++;
		}
	}
	
	public String getEstancia(){
		return nombreEstancia;
	}
	
	public void setPulsado(boolean p){
		pulsado = p;
	}
		
	public void confirmaCasilla(boolean t,Punto p,String s){
		int res = JOptionPane.showConfirmDialog( this,"�Estas seguro?","Confirma estancia",JOptionPane.YES_NO_OPTION );
	    if( res == JOptionPane.YES_OPTION ){
	      	  punto = p;
	      	  nombreEstancia = s;
	      	  pulsado = t;
	    }
	}
	
	public boolean getMoverse(){
		return moverse;
	}
	
	public boolean getPulsado(){
		return pulsado;
	}
	
	public void vaciaEstancias(){
		Iterator<Room> iter = estancias.iterator();
		while(iter.hasNext()){
			Room r = (Room) iter.next();
			iter.remove();
		}
	}
	
	public void error(){
		JOptionPane.showMessageDialog(this,"No te toca mover","Error",JOptionPane.ERROR_MESSAGE);
	}
	
	public void errorMovimiento(){
		JOptionPane.showMessageDialog(this,"No puedes moverte ahi","Error de movimiento",JOptionPane.WARNING_MESSAGE);
	}
	
	public void revelacion(){ 
		/*int res = JOptionPane.showConfirmDialog( this,"�Desea hacer una revelacion?","Revelacion",JOptionPane.YES_NO_OPTION );    
        if( res == JOptionPane.YES_OPTION ){*/
        	SwingUtilities.invokeLater(new Runnable(){  
                public void run(){     
                	revAcus.setEnabled(true);
                	revAcus.setForeground(Color.GREEN);
                	mnNewMenu.setEnabled(true);
                	revelacion = dameRevelacion();              	
	            }  
            });  
      // }	   
	} 
	
	public void desactivaRevelacion(){
		revAcus.setEnabled(false);
    	mnNewMenu.setEnabled(false);
	}
	
	public String dameRevelacion(){
		int i = 0;
		boolean enc = false;
		while((i<arrayRevelacion.size())&&(!enc)){
			if(arrayRevelacion.get(i).isSelected()){
				revelacion = arrayRevelacion.get(i).getText();
				enc = true;
			}
			i++;
		}
		return revelacion;
	}
	
	public void acusacion(){ 
		/*int res = JOptionPane.showConfirmDialog( this,"�Desea hacer una acusacion?","Acusacion",JOptionPane.YES_NO_OPTION );    
        if( res == JOptionPane.YES_OPTION ){*/
        	SwingUtilities.invokeLater(new Runnable(){  
                public void run(){     
                	revAcus.setEnabled(true);
                	revAcus.setForeground(Color.GREEN);
                	mnAcusacion.setEnabled(true);
                	acusacion = dameAcusacion();
                	
	            }  
            });  
       //}	   
	} 
	
	public void desactivaAcusacion(){
		revAcus.setEnabled(false);
    	mnAcusacion.setEnabled(false);
	}
	
	public String dameAcusacion(){
		int i = 0;
		boolean enc = false;
		while((i<arrayAcusacion.size())&&(!enc)){
			if(arrayAcusacion.get(i).isSelected()){
				acusacion = arrayAcusacion.get(i).getText();
				enc = true;
			}
			i++;
		}
		return acusacion;
	}
	
	public void ponJugadorArray(Jugador j){
		arrayJug.add(j);
	}
	
	public ArrayList<Jugador> dameArrayJugadores(){
		return arrayJug;
	}
	
	public void vaciaJugadorArray(){
		Iterator<Jugador> iter = arrayJug.iterator();
		while(iter.hasNext()){
			Jugador j = (Jugador) iter.next();
			iter.remove();
		}
	}
	
	class PanelMouseListener extends MouseAdapter implements MouseMotionListener {
		
		//Se activa si se pulsa un bot�n y no se mantiene pulsado: 
		public void mouseClicked(MouseEvent e){
			int i = 0;
			Room r = null;
			if(moverse){
				while(i<todasEstancias.size()){
					r = todasEstancias.get(i);
					if(((estancias.contains(r))&&(e.getX()>todasEstancias.get(i).getPuntoA().getX())&&(e.getY()>todasEstancias.get(i).getPuntoA().getY())
						&&(e.getX()<todasEstancias.get(i).getPuntoB().getX())&&(e.getY()<todasEstancias.get(i).getPuntoB().getY()))){
							labelJugadores.get(numJugador-1).setBounds(e.getX()-12, e.getY()-62, 60, 30);			
							confirmaCasilla(true,new Punto(e.getX(),e.getY()),todasEstancias.get(i).getNombre());
							moverse = false;
					}
					i++;
				}
			}
			else error();
		}
		//Se activa cuando el mouse entra en el Panel: 
		public void mouseEntered(MouseEvent e){
			
		}
	    //Se activa cuando el mouse sale del Panel: 
		public void mouseExited(MouseEvent e){
			
		}
		//Se activa si se pulsa un bot�n y s� se mantiene pulsado: 
		public void mousePressed(MouseEvent e){
			
		}
		//Se activa cuando se suelta el bot�n presionado previamente (an�loga de mousePressed):
		public void mouseReleased(MouseEvent e){
			
		}
		//Se activa cuando arrastramos el mouse con un bot�n pulsado: 
		public void mouseDragged(MouseEvent e){
			
		}
		//Se activa cuando se produce un movimiento del mouse: 
		public void mouseMoved(MouseEvent e){
		
		}
	}
}

	