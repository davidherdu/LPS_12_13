package es.ucm.fdi.lps.g08.vistaGUI;

import java.awt.EventQueue;
import java.awt.event.*;

import javax.swing.*;

import es.ucm.fdi.lps.g08.Barba;
import es.ucm.fdi.lps.g08.Capucha;
import es.ucm.fdi.lps.g08.Complexion;
import es.ucm.fdi.lps.g08.Orden;
import es.ucm.fdi.lps.g08.TipoRasgo;
import es.ucm.fdi.lps.g08.TipoUbicacion;
import es.ucm.fdi.lps.g08.Titulo;

public class InterfazPreguntas extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> comboCaracteristicas,comboUbicacion;
	private JButton btnAceptar;
	private JLabel lblcuantosMonjes,lblTienesEn,lblNewLabel;
	private String caracteristica,lugar;
	private TipoRasgo tr;
	private TipoUbicacion tu;
	private boolean aceptar;
	
	public InterfazPreguntas() {
		super("Elige la pregunta");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//No permite Maximizar la ventana
		setResizable(false);
		setSize(684, 200);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		tr = null;
		tu = null;
		aceptar = false;
	}
	
	public void preguntaTipo1(){
		lblcuantosMonjes = new JLabel("\u00BFCuantos monjes");
		lblcuantosMonjes.setBounds(10, 50, 101, 14);
		getContentPane().add(lblcuantosMonjes);
		
		comboCaracteristicas = new JComboBox<String>();
		comboCaracteristicas.setBounds(121, 47, 147, 20);
		//comboCaracteristicas.setModel(new DefaultComboBoxModel(new String[] {"Padres","Hermanos","Novicios","Templarios","Benedictinos","Franciscano","Con capucha","Sin capucha","Con barba","Afeitado","Gordo","Delgado"}));
		comboCaracteristicas.addItem("Padres");
		comboCaracteristicas.addItem("Hermanos");
		comboCaracteristicas.addItem("Novicios");
		comboCaracteristicas.addItem("Templarios");
		comboCaracteristicas.addItem("Benedictinos");
		comboCaracteristicas.addItem("Franciscano");
		comboCaracteristicas.addItem("Con capucha");
		comboCaracteristicas.addItem("Sin capucha");
		comboCaracteristicas.addItem("Con barba");
		comboCaracteristicas.addItem("Afeitado");
		comboCaracteristicas.addItem("Gordo");
		comboCaracteristicas.addItem("Delgado");
		//comboCaracteristicas.addItemListener(this);
		getContentPane().add(comboCaracteristicas);
		
		comboUbicacion = new JComboBox<String>();
		comboUbicacion.setBounds(350, 47, 259, 20);
		//comboUbicacion.setModel(new DefaultComboBoxModel(new String[] {"las cartas de sospechoso","la lista de sospechosos descartados"}));
		comboUbicacion.addItem("las cartas de sospechoso");
		comboUbicacion.addItem("la lista de sospechosos descartados");
		//comboUbicacion.addItemListener(this);
		getContentPane().add(comboUbicacion);
		
		lblTienesEn = new JLabel("tienes en ");
		lblTienesEn.setBounds(278, 50, 59, 14);
		getContentPane().add(lblTienesEn);
		
		lblNewLabel = new JLabel("?");
		lblNewLabel.setBounds(630, 50, 46, 14);
		getContentPane().add(lblNewLabel);
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.setBounds(263, 113, 89, 23);
		getContentPane().add(btnAceptar);
		
		ActionListener al = new ActionListener() { 
	         public void actionPerformed(ActionEvent e){ 
	            Object obj = e.getSource(); 
	            if (obj == btnAceptar) 
	            	btnAceptarActionPerformed(e);    	
	            	aceptar = true;
	         }
	    };  	
	    btnAceptar.addActionListener(al);
	}
	
	public void preguntaTipo2(){
		lblcuantosMonjes = new JLabel("\u00BFTienes a ");
		lblcuantosMonjes.setBounds(10, 50, 80, 14);
		getContentPane().add(lblcuantosMonjes);
		
		comboCaracteristicas = new JComboBox();
		comboCaracteristicas.setBounds(90, 47, 147, 20);
		comboCaracteristicas.setModel(new DefaultComboBoxModel(new String[] {"Matthew","William","Fortune","Harold","Malachi","Gerard","Basil","Thomas","Galbraith","Michael","Emmanuel",
				 															 "Cuthbert","Jacques","Bartholomew","Andre","Nicholas","Bruno","Sergio","Berengar","Julian","Cyrille","Charles","Philippe","Guy"}));
		//comboCaracteristicas.addItemListener(this);
		getContentPane().add(comboCaracteristicas);
		
		comboUbicacion = new JComboBox();
		comboUbicacion.setBounds(280, 47, 259, 20);
		comboUbicacion.setModel(new DefaultComboBoxModel(new String[] {"las cartas de sospechoso","la lista de sospechosos descartados"})); 
		//comboUbicacion.addItemListener(this);
		getContentPane().add(comboUbicacion);
		
		lblTienesEn = new JLabel(" en ");
		lblTienesEn.setBounds(250, 50, 20, 14);
		getContentPane().add(lblTienesEn);
		
		lblNewLabel = new JLabel("?");
		lblNewLabel.setBounds(540, 50, 46, 14);
		getContentPane().add(lblNewLabel);
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.setBounds(263, 113, 89, 23);
		getContentPane().add(btnAceptar);
		
		ActionListener al = new ActionListener() { 
	         public void actionPerformed(ActionEvent e){ 
	            Object obj = e.getSource(); 
	            if (obj == btnAceptar) 
	            	btnAceptarActionPerformed(e);  
	            	aceptar = true;
	         }
	    };  	
	    btnAceptar.addActionListener(al);
	}
	
	private void btnAceptarActionPerformed(ActionEvent e){
		if(e.getSource()==btnAceptar){
			caracteristica = (String)comboCaracteristicas.getSelectedItem();
			lugar = (String)comboUbicacion.getSelectedItem();
			enlazar(caracteristica,lugar);
			dispose();
		}
	}
	
	public boolean dameAceptar(){
		return aceptar;
	}
	
	public String pregunta(){
		return lblcuantosMonjes.getText()+" "+caracteristica+" "+lblTienesEn.getText()+" "+lugar+lblNewLabel.getText();
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfazPreguntas frame = new InterfazPreguntas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void enlazar(String car,String lug){
		switch(car){
			case "Padres": tr = new TipoRasgo(Titulo.padre);
						   break;
			case "Hermanos": tr = new TipoRasgo(Titulo.hermano);
							 break;
			case "Novicios": tr = new TipoRasgo(Titulo.novicio);
							 break;
			case "Templarios": tr = new TipoRasgo(Orden.templario);
							   break;
			case "Franciscano": tr = new TipoRasgo(Orden.franciscano);
								 break;
			case "Benedictinos": tr = new TipoRasgo(Orden.benedictino);
								 break;
			case "Con capucha": tr = new TipoRasgo(Capucha.con_capucha);
							    break;
			case "Sin capucha": tr = new TipoRasgo(Capucha.sin_capucha);
		    				    break;
			case "Con barba": tr = new TipoRasgo(Barba.barba);
							  break;
			case "Afeitado": tr = new TipoRasgo(Barba.afeitado);
						     break;
			case "Gordo": tr = new TipoRasgo(Complexion.gordo);
						  break;
			case "Delgado": tr = new TipoRasgo(Complexion.delgado);
					        break;
		    default: break;
		}
		switch(lug){
			case "las cartas de sospechoso": tu = TipoUbicacion.cartas_de_sospechoso;
											 break;
			case "la lista de sospechosos descartados": tu = TipoUbicacion.monjes_tachados;
														break;
			default: break;
		}
	}

	//@Override
	/*public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==comboCaracteristicas) {
			caracteristica = (String)comboCaracteristicas.getSelectedItem();
			switch(caracteristica){
				case "Padres": tr = new TipoRasgo(Titulo.padre);
							   break;
				case "Hermanos": tr = new TipoRasgo(Titulo.hermano);
								 break;
				case "Novicios": tr = new TipoRasgo(Titulo.novicio);
								 break;
				case "Templarios": tr = new TipoRasgo(Orden.templario);
								   break;
				case "Franciscano": tr = new TipoRasgo(Orden.franciscano);
									 break;
				case "Benedictinos": tr = new TipoRasgo(Orden.benedictino);
									 break;
				case "Con capucha": tr = new TipoRasgo(Capucha.con_capucha);
								    break;
				case "Sin capucha": tr = new TipoRasgo(Capucha.sin_capucha);
			    				    break;
				case "Con barba": tr = new TipoRasgo(Barba.barba);
								  break;
				case "Afeitado": tr = new TipoRasgo(Barba.afeitado);
							     break;
				case "Gordo": tr = new TipoRasgo(Complexion.gordo);
							  break;
				case "Delgado": tr = new TipoRasgo(Complexion.delgado);
						        break;
			    default: break;
			}
        }
		if(e.getSource()==comboUbicacion){
			lugar = (String)comboUbicacion.getSelectedItem();
			switch(lugar){
				case "las cartas de sospechoso": tu = TipoUbicacion.cartas_de_sospechoso;
												 break;
				case "la lista de sospechosos descartados": tu = TipoUbicacion.monjes_tachados;
															break;
				default: break;
			}
		}
	}*/
	
	public TipoRasgo dameTipoRasgo(){
		return tr;
	}
	
	public String dameCaracteristica(){
		return caracteristica;
	}
	
	public TipoUbicacion dameTipoUbicacion(){
		return tu;
	}
	
}
