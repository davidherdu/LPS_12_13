package es.ucm.fdi.lps.g08;

public enum Barba {barba,afeitado}
